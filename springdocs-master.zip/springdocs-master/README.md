 Spring文档(5.2.6)翻译：中文版
---
基于[5.2.6](https://docs.spring.io/spring/docs/5.2.6.RELEASE/spring-framework-reference/core.html)
## [The IoC Container](https://www.hellooooo.top/blog/43)

第一部分已经完成，当前,可以在我[博客](https://www.hellooooo.top/blog/43 )查看，也可以在md目录下查看

## [Resources](https://www.hellooooo.top/blog/44)

第二部分已经完成，当前,可以在我[博客](https://www.hellooooo.top/blog/44 )查看，也可以在md目录下查看


## [Validation, Data Binding, and Type Conversion](https://www.hellooooo.top/blog/45 )

第三部分已经完成，当前,可以在我[博客](https://www.hellooooo.top/blog/45 )查看，也可以在md目录下查看

## [Spring Expression Language (SpEL)](https://www.hellooooo.top/blog/46 )

第四部分已经完成，当前,可以在我[博客](https://www.hellooooo.top/blog/46 )查看，也可以在md目录下查看

5.25:relieved:
唉，要考试了，翻译进度慢一点吧

5.29 贼难受​:cry:​

5.31 慢慢来

## [Aspect Oriented Programming with Spring](https://www.hellooooo.top/blog/51 )
第五部分已经完成，当前,可以在我[博客](https://www.hellooooo.top/blog/51 )查看，也可以在md目录下查看
7.17 不慌

## Spring AOP APIs
**翻译中**

## Null-safety
**翻译中**

## Data Buffers and Codecs
**翻译中**

如有任何建议或意见，烦请邮箱联系